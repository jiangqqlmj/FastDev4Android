package com.chinaztt.fda.spreference;

/**
 * 当前类注释:当前类用户SharedPreferences进行save的时候 配置key常量
 * 项目名：FastDev4Android
 * 包名：com.chinaztt.fda.spreference
 * 作者：江清清 on 15/10/22 09:26
 * 邮箱：jiangqqlmj@163.com
 * QQ： 781931404
 * 公司：江苏中天科技软件技术有限公司
 */
public class SharedPreferencesTag {
    public static final String DEMO_KEY="demo_key";

}
